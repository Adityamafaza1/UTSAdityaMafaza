package com.example.navy

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView

class tentang : AppCompatActivity() {
    companion object {
        const val EXTRA_NAME = "extra_name"
        const val EXTRA_NIM = "extra_nim"

    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tentang)

        val renderActivit: TextView = findViewById(R.id.namaSaya)


        val nama = intent.getStringExtra(EXTRA_NAME)


        val text = "Nama : $nama"
        renderActivit.text = text

        val rendeerNIM: TextView = findViewById(R.id.nim)

        val nim = intent.getIntExtra(EXTRA_NIM, 0)

        val textt = "NIM : $nim"
        rendeerNIM.text = textt

    }
}
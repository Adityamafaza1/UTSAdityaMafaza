package com.example.navy

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.ImageView
import android.widget.TextView

class DetailActivity : AppCompatActivity(), View.OnClickListener {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_detail)

        val shoes = intent.getParcelableExtra<Shoes>("shoes")

        if (shoes != null) {
            val imageView = findViewById<ImageView>(R.id.detail_img_item_photo)
            val nameTextView = findViewById<TextView>(R.id.detail_tv_item_name)
            val descriptionTextView = findViewById<TextView>(R.id.detail_tv_item_description)

            imageView.setImageResource(shoes.photo)
            nameTextView.text = shoes.name
            descriptionTextView.text = shoes.description
        }

        val profileButton = findViewById<View>(R.id.Profile)
        profileButton.setOnClickListener(this)
    }

    override fun onClick(view: View) {
        when (view.id) {
            R.id.Profile -> {
                val moveIntent = Intent(this@DetailActivity, tentang::class.java)
                moveIntent.putExtra(tentang.EXTRA_NAME, "Aditya Mafaza")
                moveIntent.putExtra(tentang.EXTRA_NIM, 211220065)
                startActivity(moveIntent)
            }
        }
    }
}

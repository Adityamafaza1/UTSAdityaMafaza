package com.example.navy

import android.os.Parcelable
import kotlinx.parcelize.Parcelize

@Parcelize
data class Shoes(
    val name: String,
    val description: String,
    val photo: Int

) :Parcelable

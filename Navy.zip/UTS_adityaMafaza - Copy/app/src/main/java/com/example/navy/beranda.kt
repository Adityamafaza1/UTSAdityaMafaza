package com.example.navy

import android.content.Intent
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView

class beranda : AppCompatActivity() {
    private lateinit var item: RecyclerView
    private val list: ArrayList<Shoes> = ArrayList()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_beranda)

        item = findViewById(R.id.item)
        item.setHasFixedSize(true)

        list.addAll(getListShoes())
        showRecyclerList()

        val adapter = ListShoesAdapter(list)
        item.adapter = adapter

        adapter.setItemClickListener(object : ListShoesAdapter.ItemClickListener {
            override fun onItemClick(shoes: Shoes) {
                val intent = Intent(this@beranda, DetailActivity::class.java)
                intent.putExtra("shoes", shoes)
                startActivity(intent)
            }
        })
    }

    private fun getListShoes(): ArrayList<Shoes> {
        val dataName = resources.getStringArray(R.array.data_name)
        val dataDescription = resources.getStringArray(R.array.data_description)
        val dataPhoto = resources.obtainTypedArray(R.array.data_photo)
        val listShoes = ArrayList<Shoes>()
        for (i in dataName.indices) {
            val shoes = Shoes(dataName[i], dataDescription[i], dataPhoto.getResourceId(i, -1))
            listShoes.add(shoes)
        }
        return listShoes
    }

    private fun showRecyclerList() {
        item.layoutManager = LinearLayoutManager(this)
        val listShoesAdapter = ListShoesAdapter(list)
        item.adapter = listShoesAdapter
    }
}
